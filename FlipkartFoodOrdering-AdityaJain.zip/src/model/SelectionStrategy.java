package model;

public enum SelectionStrategy {
    LOWEST_COST
}
