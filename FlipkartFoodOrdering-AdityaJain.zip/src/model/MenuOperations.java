package model;

public enum MenuOperations {
    ADD,
    UPDATE
}
