package selector;

import model.Dish;
import model.Order;
import model.Restaurant;

import java.util.List;

public interface RestaurantSelector {

    Restaurant getRestaurant(List<Restaurant> restaurants, List<Dish> dishList);
}
